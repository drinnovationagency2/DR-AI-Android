D R AI Android Starter Project
===============================

यह Android Studio/Gradle source project है, तैयार APK नहीं।

इस प्रोजेक्ट में:
- D R AI का basic Android app
- हिंदी speech-to-text (मोबाइल की speech service उपलब्ध होने पर)
- हिंदी text-to-speech
- समय/तारीख जैसे सीमित local demo जवाब
- Android Assistant role request button

महत्वपूर्ण सीमाएँ:
1. यह अभी Gemini/किसी AI मॉडल से कनेक्ट नहीं है।
2. यह "Hey D R" wake-word नहीं सुनता।
3. स्क्रीन लॉक होने पर लगातार माइक्रोफोन नहीं चलता।
4. Assistant role request दिखना, पूर्ण system assistant या hotword support की गारंटी नहीं है।
5. APK बनाने और वास्तविक Android 14 डिवाइस पर परीक्षण की जरूरत है।

APK build:
- Android Studio में इस folder को खोलें।
- Gradle sync करें।
- Build > Build Bundle(s) / APK(s) > Build APK(s).

सुरक्षा:
- किसी API key को APK के source code में न डालें।
- AI API के लिए सुरक्षित backend आवश्यक है।
