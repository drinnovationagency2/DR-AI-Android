package com.drinnovation.drai

import android.Manifest
import android.app.Activity
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var output: TextView
    private lateinit var input: EditText
    private lateinit var tts: TextToSpeech
    private var recognizer: SpeechRecognizer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildScreen()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 10)
        }
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 32, 24, 24)
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(0xFF071A35.toInt())
        }
        val title = TextView(this).apply {
            text = "D R AI"
            textSize = 30f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        }
        val sub = TextView(this).apply {
            text = "Personal AI Assistant • DR Innovation Agency"
            textSize = 13f
            setTextColor(0xFFB8D8F5.toInt())
            gravity = Gravity.CENTER
        }
        output = TextView(this).apply {
            text = "नमस्ते! मैं D R AI हूँ। नीचे अपना सवाल लिखें या बोलें।\\n\\nअभी AI सर्वर कनेक्शन जोड़ा नहीं गया है।"
            textSize = 17f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(16, 24, 16, 24)
        }
        input = EditText(this).apply {
            hint = "अपना सवाल लिखें..."
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFF9BB6D0.toInt())
            setPadding(14, 12, 14, 12)
            setBackgroundColor(0xFF163456.toInt())
        }
        val send = Button(this).apply {
            text = "भेजें"
            setOnClickListener { answerLocally(input.text.toString()) }
        }
        val speak = Button(this).apply {
            text = "🎙 बोलकर पूछें"
            setOnClickListener { startListening() }
        }
        val assistant = Button(this).apply {
            text = "Default Assistant सेट करें"
            setOnClickListener { requestAssistantRole() }
        }
        listOf(title, sub, output, input, send, speak, assistant).forEach {
            root.addView(it, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                if (it == output) 0 else LinearLayout.LayoutParams.WRAP_CONTENT,
                if (it == output) 1f else 0f
            ).apply { if (it != title) topMargin = 12 })
        }
        val footer = TextView(this).apply {
            text = "Powered by DR Innovation Agency"
            textSize = 12f
            setTextColor(0xFF8CA9C8.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 20, 0, 0)
        }
        root.addView(footer)
        setContentView(root)
    }

    private fun answerLocally(question: String) {
        if (question.isBlank()) {
            output.text = "कृपया पहले सवाल लिखें या बोलें।"
            return
        }
        val q = question.lowercase(Locale.ROOT)
        val answer = when {
            q.contains("namaste") || q.contains("hello") || q.contains("नमस्ते") ->
                "नमस्ते! बताइए, मैं आपकी क्या मदद करूँ?"
            q.contains("time") || q.contains("समय") ->
                "आपके मोबाइल का समय: " + java.text.SimpleDateFormat("hh:mm a", Locale.getDefault()).format(java.util.Date())
            q.contains("date") || q.contains("तारीख") ->
                "आज की तारीख: " + java.text.SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(java.util.Date())
            else ->
                "आपका सवाल मिला: \"$question\"\\n\\nयह अभी बेसिक डेमो मोड है। असली AI जवाब पाने के लिए सुरक्षित AI API सर्वर जोड़ना होगा।"
        }
        output.text = answer
        tts.speak(answer, TextToSpeech.QUEUE_FLUSH, null, "dr_ai_reply")
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            output.text = "इस मोबाइल में Speech Recognition उपलब्ध नहीं है।"
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : android.speech.RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { output.text = "सुन रहा हूँ..." }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) { output.text = "आवाज़ समझ नहीं आई। दोबारा कोशिश करें।" }
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                input.setText(text)
                answerLocally(text)
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "D R AI से बोलें")
        }
        recognizer?.startListening(intent)
    }

    private fun requestAssistantRole() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val roleManager = getSystemService(Context.ROLE_SERVICE) as RoleManager
            if (roleManager.isRoleAvailable(RoleManager.ROLE_ASSISTANT)) {
                startActivityForResult(roleManager.createRequestRoleIntent(RoleManager.ROLE_ASSISTANT), 20)
            } else {
                output.text = "इस डिवाइस पर Assistant role उपलब्ध नहीं है।"
            }
        } else {
            output.text = "Default Assistant चयन के लिए Android 10 या नया संस्करण चाहिए।"
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts.language = Locale("hi", "IN")
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts.stop()
        tts.shutdown()
        super.onDestroy()
    }
}
